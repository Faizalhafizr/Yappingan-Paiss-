# Social Mockup Studio — Threads-first

## Fitur
- Fokus antarmuka pada Threads; template awal bernama **Nama Contoh** dan teks awal `hi`.
- Badge centang dari `assets/images/verified.png` disejajarkan secara vertikal dengan nama.
- Baris interaksi empat ikon dibuat lebih rapat dan tetap responsif pada layar ponsel.
- Rasio kanvas: otomatis (rasio alami kartu Threads), 1:1, 4:5, dan 9:16.
- Foto profil utama dan foto profil setiap balasan mendukung crop vertikal.
- Preset statistik: sepi, normal, viral, dan nol; angka tetap bisa diedit manual.
- Setiap balasan bisa memiliki nama, waktu, foto profil, serta statistiknya sendiri.
- Label SIMULASI opsional dan nonaktif secara default.
- Template profil dapat disimpan, dipakai ulang, dan dihapus memakai `localStorage` browser; foto profil, nama, centang biru, waktu, statistik, dan gaya tersimpan, sedangkan teks post, balasan, serta catatan post tidak ikut tersimpan.
- Proyek penuh tetap dapat disimpan/dimuat sebagai JSON; CSS dan JavaScript tetap modular di `data/`.

## Template lokal
Template tersimpan hanya pada browser dan origin/domain yang sama di perangkat tersebut. Membersihkan data situs/browser atau membuka proyek dari alamat lokal yang berbeda dapat membuat template tidak tersedia. Untuk foto profil, gunakan gambar yang tidak terlalu besar agar tidak memenuhi kuota penyimpanan browser.

## Menjalankan
Ekstrak ZIP dan buka `index.html` melalui local preview/server yang mendukung ES modules.

## Ekspor PNG
Ekspor PNG memakai html2canvas melalui CDN, sehingga koneksi internet diperlukan untuk memuat pustaka tersebut. Saya tidak dapat menyertakan salinan offline html2canvas pada paket ini karena akses jaringan saat pembuatan tidak tersedia. Jika pustaka gagal dimuat, aplikasi akan menampilkan pemberitahuan dan tidak mengklaim ekspor berhasil.

## Catatan
Rasio otomatis adalah pilihan yang paling menyerupai post Threads: kartu mengikuti lebar area pratinjau dan tinggi konten, bukan dipaksa menjadi gambar persegi. Rasio 1:1, 4:5, dan 9:16 tersedia sebagai kanvas opsional untuk kebutuhan berbagi gambar.


### Berbagi PNG
Tombol **Bagikan** menggunakan menu berbagi Android/browser jika browser mendukung berbagi file. Jika tidak, PNG akan diunduh agar bisa dibagikan dari Galeri. Ekspor gambar memerlukan koneksi internet untuk memuat html2canvas dari CDN.
